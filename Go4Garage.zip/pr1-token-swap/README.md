# PR 1 — Editorial Token Swap (Drop-in)

This is a **token-only** redesign. No content, no scripts, no Firebase, no
analytics, no video, no logo, no SEO — nothing functional changes. Only the
**design tokens, palette, and fonts** are swapped from the generic MD3
amber/purple/green to a bone / ink / saffron editorial system.

## What's in this folder

```
pr1-token-swap/
├── app/
│   ├── globals.css      ← drop-in replacement for app/globals.css
│   └── layout.tsx       ← drop-in replacement for app/layout.tsx
└── tailwind.config.ts   ← drop-in replacement for tailwind.config.ts
```

## What changes (in plain English)

| Token / area      | Before                                | After                                  |
|-------------------|---------------------------------------|----------------------------------------|
| **Page bg**       | `#ffffff` white                       | `#f5efe2` warm bone paper             |
| **Body text**     | `#1c1b1b`                             | `#1a1714` warm ink                    |
| **Primary**       | `#904d00` brown amber                 | `#c84d0d` saffron deep                |
| **Primary container** | `#f18a22`                         | `#f06b1a` saffron                      |
| **Secondary**     | `#7b41b3` purple                      | `#1a1714` warm ink                     |
| **Tertiary**      | `#006e2f` green                       | `#4a6240` muted earthy green          |
| **Outline**       | `#000000` black borders               | `#1a1714` ink + `#d4cab0` rule        |
| **Display font**  | Space Grotesk                         | **Fraunces** (Space Grotesk = fallback)|
| **Body font**     | Inter                                 | Inter (UNCHANGED)                      |
| **Mono font**     | _none_                                | **JetBrains Mono** (added)            |
| **Devanagari**    | _none_                                | **Noto Sans Devanagari** (added)      |
| **Theme-color**   | `#904d00`                             | `#c84d0d`                             |

## What does NOT change

- ✅ Every existing component still uses the same class names
  (`bg-primary`, `text-secondary`, `border-outline`, `font-display`, etc.)
- ✅ All metadata, OG tags, Twitter cards, structured data
- ✅ Firebase, GTM, analytics, app check, remote config
- ✅ Service worker, cookie consent, exit-intent modal
- ✅ Logo preload (`/logo.jpg`)
- ✅ Material Symbols icon set
- ✅ All videos, images, copy, navigation, footer
- ✅ All routes and content in `HomeClient.tsx`, `PlatformClient.tsx`, etc.

## How to apply

```bash
# 1. From your repo root, copy the three files in:
cp <path-to>/pr1-token-swap/app/globals.css     app/globals.css
cp <path-to>/pr1-token-swap/app/layout.tsx      app/layout.tsx
cp <path-to>/pr1-token-swap/tailwind.config.ts  tailwind.config.ts

# 2. Commit
git checkout -b design/pr1-editorial-tokens
git add app/globals.css app/layout.tsx tailwind.config.ts
git commit -m "design: editorial token swap (PR 1) — bone/ink/saffron palette + Fraunces"

# 3. Deploy to a Firebase preview channel first (matches your existing flow)
npm run deploy:preview

# 4. Once preview looks right, ship to prod
git push origin design/pr1-editorial-tokens
# (open PR, review, merge, and your existing CI deploys)
```

## What you should see

1. **Whole site flips from white → bone paper.** Every section, card, hero —
   warm, editorial, immediately reads as Indian-rooted instead of generic SaaS.
2. **Headings (anything using `font-display`) become Fraunces** — a high-contrast
   editorial serif with optical sizing. Body copy stays in Inter so line
   lengths and rhythm don't shift.
3. **All `primary`-coloured elements (CTAs, accents) shift from brown amber
   to saffron** — more vivid, more Indian.
4. **Purple `secondary` chips/buttons become deep ink** — they read as
   intentional editorial accents instead of looking out of place.
5. **Scrollbar, theme-color (mobile chrome), and selection all match** the
   new system.

## What to watch for after deploy

A few sections may have *contrast* edge cases now that the bg is warm bone
instead of pure white:

- Any component that hard-codes `bg-white` (instead of `bg-surface`) — those
  will still appear as hard white islands. Find them with:
  ```bash
  grep -rn "bg-white" app/ components/
  ```
- Any component using inline hex colors. Find them with:
  ```bash
  grep -rEn "(#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3})" app/ components/
  ```
- Gradient backgrounds that mixed amber + purple — they may now look muddy.

These are PR 2 territory. They're not blockers; they'll just look slightly
inconsistent until we touch each section.

## Rollback

If anything looks wrong, rolling back is one revert:

```bash
git revert <commit-sha>
```

The three files are self-contained — no other file in the repo is modified.

---

**Next:** Once you've shipped PR 1 and reviewed the live result, ping me and
I'll generate **PR 2** — the homepage rebuild (8-layer framework hero, India
compliance map, refreshed product showcase, personas, how-it-works, AI
differentiator, final CTA).
