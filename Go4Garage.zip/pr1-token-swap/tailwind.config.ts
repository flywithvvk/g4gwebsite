import type { Config } from "tailwindcss";

/* =====================================================================
   Go4Garage — PR 1: Tailwind config mirroring editorial tokens
   =====================================================================
   Drop-in replacement for tailwind.config.ts. All existing class names
   (bg-primary, text-secondary, border-outline, font-display, etc.)
   continue to work — only their VALUES change to the editorial palette.
   New utilities (bg-paper, text-ink, text-saffron, font-deva, font-mono)
   are added for upcoming components.
   ===================================================================== */

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // ─── NEW editorial tokens ──────────────────────────────────────
        paper: {
          DEFAULT: '#f5efe2',
          mute: 'rgba(26,23,20,0.62)',
        },
        bone:    '#ebe3d0',
        ink: {
          DEFAULT: '#1a1714',
          soft:    '#3a342d',
          mute:    '#8a7f6e',
        },
        saffron: {
          DEFAULT: '#f06b1a',
          deep:    '#c84d0d',
          soft:    '#fbe7d3',
        },
        rule: '#d4cab0',

        // ─── EXISTING MD3 tokens — kept alive, remapped to editorial ──
        // Surface (was white; now warm bone paper)
        surface: {
          DEFAULT:                  '#f5efe2',
          dim:                      '#ebe3d0',
          bright:                   '#faf5e8',
          'container-lowest':       '#faf5e8',
          'container-low':          '#f5efe2',
          container:                '#ebe3d0',
          'container-high':         '#e1d8be',
          'container-highest':      '#d4cab0',
        },
        // Primary (was amber; now saffron)
        primary: {
          DEFAULT:        '#c84d0d',
          container:      '#f06b1a',
          on:             '#ffffff',
          'on-container': '#2a1305',
        },
        // Secondary (was purple; now warm ink so old purple reads as deep editorial)
        secondary: {
          DEFAULT:        '#1a1714',
          container:      '#3a342d',
          on:             '#f5efe2',
          'on-container': '#f5efe2',
        },
        // Tertiary (was green; now muted earthy green)
        tertiary: {
          DEFAULT:        '#4a6240',
          container:      '#8aa377',
          on:             '#ffffff',
          'on-container': '#1a2614',
        },
        // Error
        error: {
          DEFAULT:   '#b3321a',
          container: '#fbe1d6',
        },
        // Outline (was black; now editorial ink)
        outline: {
          DEFAULT: '#1a1714',
          variant: '#d4cab0',
        },
        // On-surface text
        'on-surface': {
          DEFAULT: '#1a1714',
          variant: '#3a342d',
        },
        // Inverse — for dark sections
        'inverse-surface':    '#1a1714',
        'inverse-on-surface': '#f5efe2',
        'inverse-primary':    '#f06b1a',
      },
      fontFamily: {
        // sans = body (Inter unchanged — existing copy doesn't reflow)
        sans:    ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        // display = Fraunces (was Space Grotesk; opt-in via class="font-display")
        display: ['Fraunces', 'Space Grotesk', 'Inter', 'Georgia', 'serif'],
        // NEW
        mono:    ['JetBrains Mono', 'SF Mono', 'Menlo', 'Consolas', 'monospace'],
        deva:    ['Noto Sans Devanagari', 'Inter', 'sans-serif'],
      },
      letterSpacing: {
        widest: '0.2em',
      },
    },
  },
  plugins: [],
};

export default config;
